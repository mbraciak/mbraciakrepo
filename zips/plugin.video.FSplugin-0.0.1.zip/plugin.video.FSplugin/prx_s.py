# -*- coding: utf8 -*-

import requests

import threading, Queue, thread
import base64
import random
import xbmcgui
import xbmcplugin
import xbmc
import time
import re
list_c = [["Jack Nicholson","Moja matka nigdy nie widziała ironii w nazywaniu mnie sukinsynem."],
["Bob Hope","Bank to miejsce, które pożyczy ci pieniądze, jeśli możesz udowodnić, że ich nie potrzebujesz."],
["Caroline Rhea","Moim ulubionym urządzeniem na siłowni jest automat z przekąskami."],
["Albert Einstein","Tylko dwie rzeczy są nieskończone"],
["Greg King","Nie kłóć się z idiotą, bo najpierw sprowadzi cię do swojego poziomu, a potem pokona doświadczeniem."],
["Erma Bombeck","Szansa na pójście do sklepu po chleb i wyjście tylko z chlebem jest jak trzy miliardy do jednego."],
["David Brenner","Skąpcy nie są przyjemnymi partnerami do życia, ale za to wspaniale nadają się na przodków."],
["Robert Wilensky","Wszyscy słyszeliśmy, że milion małp przy milionie klawiatur mogło wyprodukować Dzieła Zebrane Szekspira; ale dzięki Internetowi wiemy, że to nieprawda."],
["Elayne Boosler","Mam sześć zamków w drzwiach. Kiedy wychodzę, zamykam co drugi z nich. Uznałam, że bez względu na to, jak długo ktoś będzie stał pod drzwiami, próbując otworzyć te zamki, zawsze trzy z nich zablokuje, zamiast otworzyć."],
["Bill McGlashen","Cierpliwość jest czymś, za co podziwiamy kierowcę jadącego za nami, ale nie tego, który jedzie przed nami."],
["Al McGuire","Jedyną tajemnicą życia jest to, dlaczego piloci kamikaze nosili hełmy."],
["Miles Kington","Wiedza polega na tym, że mamy świadomość, iż pomidor to owoc. Mądrość polega na tym, że nie dodajemy go do sałatki owocowej."],
["Wilde Oscar Wilde"," Zawsze pożyczaj pieniądze od pesymistów. Nie będzie spodziewał się ich zwrotu."],
["Jerry Seinfeld","Według większości badań, ludzie najbardziej boją się publicznie przemawiać. Dopiero na drugim miejscu jest śmierć. Śmierć jest numerem dwa! Czy to może być prawda? Oznacza to, że przeciętny człowiek, jeśli pójdzie na pogrzeb, będzie lepiej czuł się w trumnie, niż wygłaszając przemowę."],
["Sam Levenson","Szaleństwo jest dziedziczne. Dostajesz na głowę z powodu swoich dzieci."],
["Milton Berle","Jeśli ewolucja naprawdę działa, to jak jest możliwe, że matki mają tylko dwie ręce?"],
["George Miller","Problem z jedzeniem kuchni włoskiej polega na tym, że pięć lub sześć dni później, jesteś znowu głodny."],
["Claude Pepper","Makler zachęcał mnie do zakupu akcji, które potroją swoją wartość każdego roku. Powiedziałem mu"],
["Billy Sunday","Chodzenie do kościoła nie czyni cię bardziej chrześcijaninem, niż stanie w garażu czyni cię samochodem."],
["Dave Barry","Mój terapeuta powiedział mi, że drogą do osiągnięcia prawdziwego wewnętrznego spokoju jest kończenie tego, co zaczynam. Do tej pory skończyłem dwie torebki M&M’sów i ciasto czekoladowe. Już czuję się lepiej."],
["Mark Russell","Najbardziej podoba mi się teoria naukowa, że ​​pierścienie Saturna składają się wyłącznie z zagubionego bagażu lotniczego."],
["George Jessel","Ludzki mózg to cudowna rzecz. Rozpoczyna pracę w chwili twoich narodzin i nigdy nie przestaje, dopóki nie staniesz na podium, by przemówić publicznie."],
["Marilyn Monroe","Kobiety, które chcą być równe mężczyznom, nie mają ambicji."],
["Steven Wright","Zamierzam żyć wiecznie. Jak na razie idzie mi całkiem nieźle."],
["Wilson Mizner","Jeśli kradniesz od jednego autora, to plagiat. Jeśli kradniesz od wielu, to są badania."],
["Robert Bloch","Przyjaźń jest jak sikanie na samego siebie"],
["Bill Vaughan","Mamy nadzieję, że gdy owady przejmą władzę nad światem, będą pamiętać z wdzięcznością, jak zabieraliśmy ich na wszystkie nasze pikniki."],
["Bob Monkhouse","Kiedy umrę, chcę odejść spokojnie, jak mój dziadek, we śnie. Nie chcę odchodzić krzycząc i wrzeszcząc, jak pasażerowie w jego samochodzie."],
["Franklin P. Jones","Kłopot z punktualnością polega na tym, że nikogo nie ma na miejscu, by mógł to docenić."],
["Norm Crosby","Kiedy idziesz do sądu, oddajesz swój los w ręce dwunastu ludzi, którzy nie byli wystarczająco mądrzy, aby wykręcić się od wypełnienia obowiązku uczestniczenia w ławie przysięgłych."],
["Charles Wadsworth","Zanim mężczyzna zda sobie sprawę, że jego ojciec miał rację, ma już syna, który uważa, że ​​się myli."],
["Henny Youngman","Jeśli na początku nie uda się... To by było na tyle, jeśli chodzi o skoki spadochronowe."],
["Emo Philips","Poprosiłem Boga o rower, ale wiem, że Bóg nie działa w ten sposób. Ukradłem więc rower i poprosiłem o przebaczenie."],
["Steve Martin","Najpierw lekarz przekazał mi dobrą wiadomość"],
["Evan Esar","Najlepszy czas, aby doradzać dzieciom, jest wówczas, gdy są wciąż wystarczająco małe, by wierzyły, że wiesz, o czym mówisz."],
["John Wilmot, hrabia Rochester","Zanim się ożeniłem, miałem sześć teorii dotyczących wychowania dzieci. Teraz mam sześcioro dzieci i żadnej teorii."],
["Dave Barry","Nigdy, w żadnym wypadku, nie łykaj na noc jednocześnie pigułki na sen i środka przeczyszczającego."],
["Douglas Adams","Uwielbiam nieprzekraczalne terminy. Lubię ten świst, który wydają w momencie, gdy przelatują mi koło nosa."],
["Isaac Asimov","Ludzie sądzący, że wiedzą wszystko, są bardzo irytujący dla tych z nas, którzy naprawdę wiedzą."],
["Joan Rivers","Nienawidzę prac domowych! Ścielisz łóżko, zmywasz naczynia – a sześć miesięcy później musisz zaczynać wszystko od nowa."],
["Flip Wilson","Myślisz, że nikt nie dostrzega twojego istnienia? Spróbuj nie zapłacić paru rat za samochód i zobacz, co się stanie."],
["Franklin P. Jones","Promocja jest czymś, czego nie potrzebujesz, po cenie, której nie możesz się oprzeć."],]
def worker(qin,qout):
    while True:
        proxies = qin.get()
        if proxies == None:
            qout.put(None)
            break
        
        timestart = time.time()
        try:
            headers = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; rv:57.0) Gecko/20100101 Firefox/57.0'}
            b = requests.get('https://fili.tv/',proxies=proxies, timeout=5, headers=headers).text
            t = time.time() - timestart
            if b.find('jedynie informacje o filmach')>0:
                #print 'Found %s, Time: %ss'%(str(proxies),str(t))
                qout.put([proxies,t])
                #return [proxies, t]
        except Exception as E:
            #print 'Error %s %s'%(str(E),str(E.args))
            pass
            
        

#w = threading.Thread(name='worker', target=worker)
def get_proxynova():
    #print 'Get from %s'%('proxynova')
    ret = []

    try:
        b= requests.get('https://www.proxynova.com/proxy-server-list/country-pl/', timeout = 5).text
    except:
        return []
    s = b.split('<td align="left"><script>document.write(')

    for g in s[1:]:
        try:
            h = g[3:g.find("');</script>")].replace("'.substr(2) + '",'')
            z = g.split('title="Proxy Port ')[1]
            z = z.split('">')[0]
            ret.append(h+':'+z)
        except:
            pass
    return ret
def idcloac():
    #print 'Get from %s'%('idcloak')
    try:
        b = requests.get('http://www.idcloak.com/proxylist/free-proxy-list-poland.html', timeout = 5).text.split('</div>IP Address</th>')[1].split('<!-- end of result part -->')[0]
    except:
        return []
    pf  =re.findall('<td>([0-9]{1,6})</td><td>([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3})</td>',b)
    ret = []
    for p,h in pf:
        ret.append('%s:%s'%(h,p))
    return ret
#print idcloac()
def get_freeproxycz():
    #print 'Get from %s'%('free-proxy')
    #print 'prx.cz'
    try:
        b = requests.get('http://free-proxy.cz/en/proxylist/country/PL/all/ping/all', timeout=5).text
    except:
        return []
    #print 'afterget'
    ret = []
    b = b.split('document.write(Base64.decode("')[1:]
    for p in b:
        try:
            h = p.split('"')[0]
            h = base64.b64decode(h)
            p = p.split("""class="fport" style=''>""")[1].split('<')[0]
            ret.append('%s:%s'%(h,p))
            #print '%s:%s'%(h,p)
        except:
            pass
    return ret

def get_gatherproxy():
    #print 'Get from %s'%('gatherproxy')
    try:
        b = requests.get('http://www.gatherproxy.com/proxylist/country/?c=Poland', timeout = 5).text
    except:
        return []
    prx = re.findall('PROXY_IP":"([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3})","PROXY_LAST_UPDATE":".{1,9}","PROXY_PORT":"([a-fA-F0-9]{1,7})"',b)
    ret = []
    for h,p in prx:
        ret.append('%s:%i'%(h,int(p,16)))
    #print ret
    return ret
#print 'gather',get_gatherproxy()

        
    
def get_proxy():
    ret = []
    ret.extend(get_proxynova())
    ret.extend(idcloac())
    ret.extend(get_gatherproxy())
    ret.extend(get_freeproxycz())
    ret = list(set(ret))
    #print 'Znaleziono %i proxy.\nTestuje'%(len(ret))
    #b = requests.get('http://free-proxy.cz/en/proxylist/country/PL/all/ping/all').text
    return ret

def test_proxy(proxy):
    pass
def get_proxies():
    ret_all = {}
    qin = Queue.Queue()
    qout = Queue.Queue()
    thr_count = 30
    for _ in range(thr_count):
        thread.start_new_thread( worker,(qin,qout))
    count_proxies = 0
    for p in get_proxy():
        #print '\n\nCzekaj szukam proxy:'
        #print 'Testing:',p,
        z = qin.put({'http': 'http://'+p})
        count_proxies+=1
        
    for i in range(thr_count):
        qin.put(None)
    progress = xbmcgui.DialogProgress()
    progress.create('Czekaj cierpliwie')
    tested_count = 0
    ct = random.sample(list_c,1)[0]
    l = len(ct)
    while thr_count>0:
        tmp = qout.get()
        #print tmp, 'get_proxies'
        if tmp!= None:
            #print tmp
            ret_all[tmp[1]]=tmp[0]
            tested_count += 1
            
            prcnt = int(( float(tested_count) /count_proxies)*100)
            tmp_c= tmp_c= ct[1][ct[1].find(' ',int((prcnt / 10.0) * (l/10.0)))+1:]
            progress.update(prcnt,'"'+ct[1]+'" ( '+ct[0]+' )','', '')
        else:
            thr_count-=1
            print thr_count
    progress.update(100,"","","ZNALEZIOOONO!")
    #print ret_all
    #print 'Ustawiam proxy ',ret_all[min(ret_all.keys())], min(ret_all.keys())
    try:
        return ret_all[min(ret_all.keys())]
    except:
        return {}
#print 'Found:', get_proxies()
#print get_proxies()
