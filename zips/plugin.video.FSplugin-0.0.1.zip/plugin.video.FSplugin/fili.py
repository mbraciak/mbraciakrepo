# -*- coding: cp1250 -*-
import requests
import json
import re
from bs4 import BeautifulSoup
class fili(object):
    URL_MAIN = 'https://fili.tv/'
    URL_MOVIES = URL_MAIN + 'filmy?ver=0&ver=1&ver=2'
    URL_SERIES = URL_MAIN + 'seriale'
    URL_IMAGE = 'http://1.fwcdn.pl/po'
    HEADERS = {'User-Agent':'Mozilla/5.0 (Windows NT 6.3; rv:58.0) Gecko/20100101 Firefox/58.0'}
    
    def __init__(self, proxies):
        self.http = requests.session()
        self.proxies = proxies

    def get_genres(self, url_genre):
        body_txt = requests.get(url_genre, headers = self.HEADERS, proxies = self.proxies).text
        genres = re.findall('<li data-gen="([a-zA-Z0-9]*)">',body_txt)
        return genres

    def get_movies(self, url_movies):
        body_txt = requests.get(url_movies, headers = self.HEADERS, proxies = self.proxies).text
        body_txt_bs = BeautifulSoup(body_txt,"html.parser")
        movies = body_txt_bs.findAll( name = "section", attrs ={'class' : 'item'})
        dict_movies =[]
        for movie in movies:
            tmp_movie = {}
            tmp_movie['url'] = movie.find('a').attrs['href']
            tmp_movie['title_both'] = movie.find('img').attrs['title']
            tmp_movie['type'] = movie.find('span', attrs = {'class':"type"}).contents[0]
            tmp_movie['title'] = movie.find('h3',attrs = {'class':'title'}).contents[0]
            tmp_movie['desc'] = movie.find('p', attrs ={'class':"desc"}).contents[0]
            tmp_movie['year'] = movie.find('span', attrs = {'class':"year"}).contents[0]
            query = tmp_movie['title'].replace(' ','%20')+'%20'+tmp_movie['year']
            data_fw = requests.get('http://www.filmweb.pl/search/live?q=%s'%(query),
                                                       headers = self.HEADERS).text
            tmp_movie['img'] = fili.URL_IMAGE + data_fw.split('\\')[2][1:]
            dict_movies.append(tmp_movie)
        return dict_movies
    
    def get_episodes(self, url_series):
        body_txt = requests.get(self.URL_MAIN[:-1]+url_series, headers = self.HEADERS, proxies = self.proxies).text
        body_txt_bs = BeautifulSoup(body_txt,"html.parser")
        seasons = body_txt_bs.find('div', attrs ={"id" : "seasons_list"}).findAll('ul')
        episodes = []
        for season in seasons:
            season_num = str(season.attrs['data-season-num'])
            for ep in season.findAll('li', attrs = {'class':'line'}):
                tmp_ep = {}
                tmp_ep_num = ep.find('a', attrs = {'class':'episodeNum'})
                
                tmp_ep['url'] = tmp_ep_num.attrs['href']
                ep_name = ep.find('a', attrs = {'class':'episodeName'}).contents[0]
                tmp_ep['name'] = ep_name
                #tmp_ep['ep_num'] = 'S'+season_num.zfill(2)+' E'+tmp_ep_num.zfill(2)
                tmp_ep['ep_num'] = 'S'+season_num+'E'+tmp_ep_num.contents[0].upper().replace('ODCINEK ','').zfill(3)
                episodes.append(tmp_ep)
        return episodes
            
    
    def search(self, query):
        headers = self.HEADERS
        headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
        headers['X-Requested-With'] = 'XMLHttpRequest'
        pyload = {'q':query}
        body_txt = requests.post(fili.URL_MAIN+'search',data=pyload, headers = headers, proxies = self.proxies).content
        body_txt = json.loads(body_txt)['data']['html'].replace('\\','')
        body_txt_bs = BeautifulSoup(body_txt,"html.parser")
        movies = body_txt_bs.find('ul').findAll('a')
        dict_movies = []
        for movie in movies:
            tmp_movie = {}
            tmp_movie['url'] = movie.attrs['href']
            tmp_movie['title'] = movie.find('div', attrs = {'class':'title'}).contents[0]
            tmp_type = movie.find('div', attrs = {'class':'info'}).contents[0]
            tmp_movie['type'] = tmp_type.split(' ')[0][:-1].lower()
            tmp_movie['year'] = tmp_type.split(' ')[1]
            query = tmp_movie['title'].replace(' ','%20')+'%20'+tmp_movie['year']
            data_fw = requests.get('http://www.filmweb.pl/search/live?q=%s'%(query),
                                   headers = self.HEADERS).text
            tmp_movie['img'] = fili.URL_IMAGE + data_fw.split('\\')[2][1:]
            #print tmp_movie
            dict_movies.append(tmp_movie)
        return dict_movies

    def get_movie_links(self, url_movie):
        body_txt = requests.get(self.URL_MAIN[:-1]+url_movie, headers = self.HEADERS,
                                proxies = self.proxies).text
        body_txt_bs = BeautifulSoup(body_txt,"html.parser")
        links = body_txt_bs.find( name = "div", attrs ={'id' : 'links'})

        type_links = links.findAll('ul')
        links_movie = []
        for tmp_type in type_links:
            #print tmp_type
            type_l = tmp_type.attrs['data-type']
            links = tmp_type.findAll('li', attrs={'class':'line'})
            for link in links:
                #print link
                tmp_link = {'type':type_l,'data_ref':link.attrs['data-ref']}
                tmp_link['host'] = link.find('span', attrs={'class':'host'}).contents[0]
                tmp_link['quality'] = link.find('span', attrs={'class':'quality'}).contents[0]
                links_movie.append(tmp_link)
        return links_movie

    def get_link(self, data_ref):
        
        body_txt = requests.get(self.URL_MAIN+'embed?salt=%s'%(data_ref,),
                                headers = self.HEADERS,
                                proxies = self.proxies).text
        try:
            return re.findall("var url \= \'(\S*)\'\;",body_txt)[0]
        except:
            pass
s = fili(None)
print s.search('robot')
            #print body_txt
##    
##b = fili(None)
##for p in b.get_episodes('https://fili.tv/serial/mr-robot/134'):
##    print p['name']+'\t'+p['url']
#print b.get_link('5856ba7ebf12851782693284')

#b.search('split')
#for c in b.get_movie_links('https://fili.tv/serial/mr-robot/s01e05/eps143xpl0itswmv/5955'):
#    print c
#print b.get_link('5a6e3e24ede7a514328a227e')
##z = open('html.html','wt')
##z.write('<html><head><meta charset="utf-8"></head><body>')
##for i in b.search('split'):
##    print i
##    z.write('<div><h2>%s (%s)</h2><br><img src="%s"/><br><p></p><br></div>'%(i['title'].encode('utf8'), i['year'].encode('utf8'), i['img'].encode('utf8')))
##    
##    #print str(i)
##    #print '\n\n'
##    
##    #print b.get_link(i['data_ref'])
##        
##   # print '\n\n\n'+'#'*15+'\n\n\n'
##        
##z.write('</body></html>')
##z.close()
