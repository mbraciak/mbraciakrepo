# -*- coding: cp1250 -*-
import sys
import xbmcgui
import xbmcplugin
import ast
import xbmc
import urllib
import urlresolver
from prx_s import get_proxies
import urlparse
import requests
#from prx_s import *
#from run2 import FTO
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
# xbmcplugin.setContent(addon_handle, 'movies')
from fili import fili
def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def getusersearch():
    kb = xbmc.Keyboard('default', 'heading')
    kb.setDefault('')
    kb.setHeading('Search')
    kb.setHiddenInput(False)
    kb.doModal()
    if (kb.isConfirmed()):
        search_term  = kb.getText()
        return(search_term)
    else:
        return
    
def play_video(video_url):
    listItem = xbmcgui.ListItem("Tesfilm", path=video_url)
    xbmc.Player().play(item=video_url, listitem=listItem)

mode = args.get('mode', None)
if mode is None:

    url = build_url({'mode': 'search', 'last_proxies':'{}'})
    li = xbmcgui.ListItem('Szukaj', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'movieGenres', 'last_proxies':'{}'})
    li = xbmcgui.ListItem('Filmy - Gatunki', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)
    
    url = build_url({'mode': 'seriesGenres', 'last_proxies':'{}'})
    li = xbmcgui.ListItem('Seriale - Gatunki', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'movieAll', 'last_proxies':'{}'})
    li = xbmcgui.ListItem('Filmy wszystkie', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)
    
    url = build_url({'mode': 'seriesAll', 'last_proxies':'{}'})
    li = xbmcgui.ListItem('Seriale wszystkie', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    
    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'search':
    search_string = getusersearch()
    try:
        
        last_proxies = ast.literal_eval(args['last_proxies'][0])
    except:
        last_proxies = {}
    if last_proxies == {}:
        last_proxies = get_proxies()
    f = fili(last_proxies)
    while True:
        try:
            founds = f.search(search_string)
            break
        except:
            last_proxies = get_proxies()
    
    
    xbmcplugin.setContent(addon_handle, 'movies')

    #url = 'http://www.vidsplay.com/wp-content/uploads/2017/04/alligator.mp4'
    for found in founds:
        if found['type'] == 'film':
            url = build_url({'mode': 'get_movie_links', 'url': found['url'].encode('utf-8'),'last_proxies':str(last_proxies)})
        elif found['type'] == 'serial':
            url = build_url({'mode': 'get_series_episodes', 'url': found['url'].encode('utf-8'),'last_proxies':str(last_proxies)})
        li = xbmcgui.ListItem('[B][COLOR green][%s] [/COLOR][I]  %s  [/I][COLOR yellow](%s)[/COLOR][/B]'%(found['type'].encode('utf-8').center(10).upper(), found['title'].encode('utf-8'),found['year'].encode('utf-8') ), iconImage=found['img'])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'get_movie_links':
    
    url_movie =  args['url'][0]
    try:
        last_proxies = ast.literal_eval(args['last_proxies'][0])
    except:
        last_proxies = {}
    if last_proxies == {}:
        last_proxies = get_proxies()
    f = fili(last_proxies)
    while True:
        try:
            movie_links = f.get_movie_links(url_movie)
            break
        except:
            last_proxies = get_proxies()
    xbmcplugin.setContent(addon_handle, 'movies')
    for link in movie_links:
        url = build_url({'mode': 'play_video', 'data_ref': link['data_ref'],'last_proxies':str(last_proxies)})
        li = xbmcgui.ListItem('[COLOR white]%s[/COLOR] [COLOR silver][ %s ] [/COLOR] [COLOR yellow] %s [/COLOR]'%(link['host'].upper().ljust(12), link['quality'], link['type']) , iconImage='DefaultFolder.png')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'get_series_episodes':
    url_movie =  args['url'][0]
    try:
        last_proxies = ast.literal_eval(args['last_proxies'][0])
    except:
        last_proxies = {}
    if last_proxies == {}:
        last_proxies = get_proxies()
    f = fili(last_proxies)
    while True:
        try:
            episodes = f.get_episodes(url_movie)
            break
        except:
            last_proxies = get_proxies()
   
    xbmcplugin.setContent(addon_handle, 'movies')            
    for ep in episodes:
        url = build_url({'mode': 'get_movie_links',  'url': ep['url'].encode('utf-8'),'last_proxies':str(last_proxies)})
        li = xbmcgui.ListItem('[COLOR black][B]%s[/B][/COLOR] [COLOR silver] %s  [/COLOR] '%(ep['ep_num'].upper(), ep['name']) , iconImage='DefaultFolder.png')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'play_video':
    data_ref = args['data_ref'][0]
    try:
        last_proxies = ast.literal_eval(args['last_proxies'][0])
    except:
        last_proxies = {}
    if last_proxies == {}:
        last_proxies = get_proxies()
    f = fili(last_proxies)
    while True:
        try:
            host_url = f.get_link(data_ref)
            break
        except:
            last_proxies = get_proxies()
    try:
        url = urlresolver.HostedMediaFile(url=host_url).resolve()
        play_video(url)
    except:
        ok = xbmcgui.Dialog().ok("Problem z linkiem","","Niedzia�aj�cy link, lub brak obs�ugi serwsiu")
        
  
